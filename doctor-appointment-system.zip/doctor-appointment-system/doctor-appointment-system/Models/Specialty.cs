﻿using System.ComponentModel.DataAnnotations;

namespace doctor_appointment_system.Models
{
    public class Specialty
    {
        [Key]
        public int SpecialtyID { get; set; }
        public string Name { get; set; }
    }
}