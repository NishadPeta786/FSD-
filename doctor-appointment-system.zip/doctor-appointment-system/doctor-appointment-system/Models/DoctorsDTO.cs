﻿using System.ComponentModel.DataAnnotations;

namespace doctor_appointment_system.Models
{
    public class DoctorsDTO
    {
        public string PhoneNo { get; set; }
    }
}
