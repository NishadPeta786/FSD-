﻿using System.ComponentModel.DataAnnotations;

namespace doctor_appointment_system.Models
{
    public class LoginUserDto
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
