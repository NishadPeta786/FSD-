﻿using Microsoft.EntityFrameworkCore;

namespace doctor_appointment_system.Models
{
    public class MyDbContext : DbContext
    {
        public MyDbContext(DbContextOptions<MyDbContext> options) : base(options)
        {

        }
        public DbSet<Users> Users { get; set; }
        public DbSet<Locations> Locations { get; set; }
        public DbSet<Specialty> Specialties { get; set; }
        public DbSet<Doctors> Doctors { get; set; }
        public DbSet<Appointments> Appointments { get; set; }
    }
}
