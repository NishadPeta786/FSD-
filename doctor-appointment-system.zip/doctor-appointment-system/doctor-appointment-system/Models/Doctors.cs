﻿using System.ComponentModel.DataAnnotations;

namespace doctor_appointment_system.Models
{
    public class Doctors
    {
        [Key]
        public int DoctorId { get; set; }
        public string Name { get; set; }
        public string PhoneNo { get; set; }        
        public int LocationId { get; set; }
    }
}
