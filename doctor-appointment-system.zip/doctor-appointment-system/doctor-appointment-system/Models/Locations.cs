﻿using System.ComponentModel.DataAnnotations;

namespace doctor_appointment_system.Models
{
    public class Locations
    {
        [Key]
        public int LocationId { get; set; }
        public string LocationName { get; set; }
    }
}
