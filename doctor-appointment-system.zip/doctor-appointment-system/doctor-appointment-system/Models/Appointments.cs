﻿using System.ComponentModel.DataAnnotations;

namespace doctor_appointment_system.Models
{
    public class Appointments
    {
        [Key]
        public int AppointmentId { get; set; }
        public int DoctorId { get; set; }
        public int UserId { get; set; }
        public int SpecialtyId { get; set; }
        public DateTime Date { get; set; }
        public TimeOnly Time { get; set; }        
    }
}
