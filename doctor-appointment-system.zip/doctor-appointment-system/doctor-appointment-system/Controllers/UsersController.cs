﻿using doctor_appointment_system.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace doctor_appointment_system.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly MyDbContext _context;

        public UsersController(MyDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        [Route("register")]
        public async Task<IActionResult> Register(RegisterUserDto registerUserDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var existingUser = await _context.Users.SingleOrDefaultAsync(u => u.Email == registerUserDto.Email);
            if (existingUser != null)
            {
                return BadRequest("User with this email already exists.");
            }

            var user = new Users
            {
                Name = registerUserDto.Name,
                Password = registerUserDto.Password, 
                Email = registerUserDto.Email,
                PhoneNo = registerUserDto.PhoneNo
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return Ok("User registered successfully.");
        }

        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> Login(LoginUserDto loginUserDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }


            var user = await _context.Users.SingleOrDefaultAsync(u => u.Email == loginUserDto.Email && u.Password == loginUserDto.Password);
            if (user == null)
            {
                return BadRequest("Invalid email or password.");
            }
            return Ok(new { User = user, Message = "Login successful." });
        }
    }
}
