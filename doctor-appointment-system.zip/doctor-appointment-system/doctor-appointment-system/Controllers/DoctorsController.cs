﻿using doctor_appointment_system.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace doctor_appointment_system.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoctorsController : ControllerBase
    {
        private readonly MyDbContext _context;

        public DoctorsController(MyDbContext context)
        {
            _context = context;
        }

        // Get doctors by LocationID
        [HttpGet("ByLocation/{locationId}")]
        public async Task<ActionResult<IEnumerable<Doctors>>> GetDoctorsByLocation(int locationId)
        {
            var doctors = await _context.Doctors.Where(d => d.LocationId == locationId).ToListAsync();
            if (doctors == null || !doctors.Any())
            {
                return NotFound();
            }
            return doctors;
        }

        [HttpPost("Login")]
        public async Task<ActionResult<Doctors>> Login([FromBody] DoctorsDTO login)
        {
            var doctor = await _context.Doctors
                .FirstOrDefaultAsync(u => u.PhoneNo == login.PhoneNo);

            if (doctor == null)
            {
                return Unauthorized();
            }

            return doctor;
        }

       
      
    }
}
