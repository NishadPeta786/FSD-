﻿using doctor_appointment_system.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace doctor_appointment_system.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AppointmentsController : ControllerBase
    {
        private readonly MyDbContext _context;

        public AppointmentsController(MyDbContext context)
        {
            _context = context;
        }

        // Get all appointments
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Appointments>>> GetAllAppointments()
        {
            return await _context.Appointments.ToListAsync();
        }

        // Get appointment by ID
        [HttpGet("{id}")]
        public async Task<ActionResult<Appointments>> GetAppointment(int id)
        {
            var appointment = await _context.Appointments.FindAsync(id);

            if (appointment == null)
            {
                return NotFound();
            }

            return appointment;
        }

        // Add a new appointment
        [HttpPost]
        public async Task<ActionResult> AddAppointment(Appointments appointment)
        {
            var appointments = 
                await _context.Appointments.Where(a => a.DoctorId == appointment.DoctorId && a.Date.Date == appointment.Date.Date).ToListAsync();
            if (appointments.Count < 5)
            {
                _context.Appointments.Add(appointment);
                await _context.SaveChangesAsync();
            }
            else
            {
                return Conflict(new { message = "NoSlots" });
            }

            return CreatedAtAction(nameof(GetAppointment), new { id = appointment.AppointmentId }, appointment);
        }

        // Delete an appointment by ID
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAppointment(int id)
        {
            var appointment = await _context.Appointments.FindAsync(id);
            if (appointment == null)
            {
                return NotFound();
            }

            _context.Appointments.Remove(appointment);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpGet("ByUser/{userId}")]
        public async Task<ActionResult<IEnumerable<dynamic>>> GetAppointmentsByUser(int userId)
        {
            var appointments = await _context.Appointments
                 .Where(a => a.UserId == userId)
                 .Join(_context.Doctors, a => a.DoctorId, d => d.DoctorId, (a, d) => new { a, d })
                 .Join(_context.Users, ad => ad.a.UserId, u => u.ID, (ad, u) => new { ad, u })
                 .Join(_context.Locations, adu => adu.ad.d.LocationId, l => l.LocationId, (adu, l) => new { adu, l })
                 .Join(_context.Specialties, adul => adul.adu.ad.a.SpecialtyId, s => s.SpecialtyID, (adul, s) => new
                 {
                     AppointmentId = adul.adu.ad.a.AppointmentId,
                     DoctorName = adul.adu.ad.d.Name,
                     UserName = adul.adu.u.Name,
                     UserEmail = adul.adu.u.Email,
                     UserPhone = adul.adu.u.PhoneNo,
                     AppointmentDate = adul.adu.ad.a.Date,
                     AppointmentTime = adul.adu.ad.a.Time,
                     LocationName = adul.l.LocationName,
                     SpecialtyName = s.Name
                 })
                 .ToListAsync();

            return appointments;
        }

        [HttpGet("ByDoctor/{doctorId}")]
        public async Task<ActionResult<IEnumerable<dynamic>>> GetAppointmentsByDoctor(int doctorId)
        {
            var appointments = await _context.Appointments
                .Where(a => a.DoctorId == doctorId)
                .Join(_context.Doctors, a => a.DoctorId, d => d.DoctorId, (a, d) => new { a, d })
                .Join(_context.Users, ad => ad.a.UserId, u => u.ID, (ad, u) => new { ad, u })
                .Join(_context.Locations, adu => adu.ad.d.LocationId, l => l.LocationId, (adu, l) => new { adu, l })
                .Join(_context.Specialties, adul => adul.adu.ad.a.SpecialtyId, s => s.SpecialtyID, (adul, s) => new
                {
                    AppointmentId = adul.adu.ad.a.AppointmentId,
                    DoctorName = adul.adu.ad.d.Name,
                    UserName = adul.adu.u.Name,
                    UserEmail = adul.adu.u.Email,
                    UserPhone = adul.adu.u.PhoneNo,
                    AppointmentDate = adul.adu.ad.a.Date,
                    AppointmentTime = adul.adu.ad.a.Time,
                    LocationName = adul.l.LocationName,
                    SpecialtyName = s.Name
                })
                .ToListAsync();

            return appointments;
        }

    }
}
